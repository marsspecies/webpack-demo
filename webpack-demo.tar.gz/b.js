function b() {
    console.log("I'm b eeeee");
}

module.exports = b;
